//
//  Options.h
//  iTennis
//
//  Created by Reza Pekan on 10-07-21.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Options : UIViewController {

}

- (IBAction)infoButtonPressed:(id)sender;
- (IBAction)infoButtonPressed1:(id)sender;
- (IBAction)infoButtonPressed2:(id)sender;
- (IBAction)infoButtonPressed3:(id)sender;

- (IBAction)done;
-(IBAction)alertMe;

@end
