//
//  iTennisViewController.h
//  iTennis
//
//  Created by Reza Pekan on 10-07-21.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iTennisViewController : UIViewController {

}

- (IBAction)infoButtonPressed:(id)sender;
- (IBAction)about;
- (IBAction)multi;

@end

