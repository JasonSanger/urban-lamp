//
//  options1.h
//  iTennis
//
//  Created by Reza Pekan on 10-07-21.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface options1 : UIViewController {

}

- (IBAction)infoButtonPressed1:(id)sender;
- (IBAction)infoButtonPressed2:(id)sender;
- (IBAction)infoButtonPressed3:(id)sender;

- (IBAction)done;

@end
