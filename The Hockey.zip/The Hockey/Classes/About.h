//
//  About.h
//  Hockey
//
//  Created by Reza Pekan on 10-07-21.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface About : UIViewController {

}

- (IBAction)launchSiteClick;
- (IBAction)done;
@end
